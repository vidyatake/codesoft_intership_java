import java.util.Scanner;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of subjects: ");
        int numberOfSubjects = scanner.nextInt();
        int[] marks = new int[numberOfSubjects];

        int totalMarks;
        for (totalMarks = 0; totalMarks < numberOfSubjects; ++totalMarks) {
            System.out.println("Enter the marks obtained out of 100 in subject " + (totalMarks + 1) + ": ");
            marks[totalMarks] = scanner.nextInt();
        }

        totalMarks = 0;
        int[] var8 = marks;
        int var7 = marks.length;

        for (int var6 = 0; var6 < var7; ++var6) {
            int mark = var8[var6];
            totalMarks += mark;
        }

        float averagePercentage = (float) totalMarks / (float) numberOfSubjects;
        String grade;
        if (averagePercentage >= 90.0F) {
            grade = "A";
        } else if (averagePercentage >= 80.0F) {
            grade = "B";
        } else if (averagePercentage >= 70.0F) {
            grade = "C";
        } else if (averagePercentage >= 60.0F) {
            grade = "D";
        } else {
            grade = "F";
        }

        System.out.println("Total marks: " + totalMarks + "/" + numberOfSubjects * 100);
        System.out.println("Average percentage: " + averagePercentage);
        System.out.println("Grade: " + grade);
        System.out.println("---------------------THANK YOU------------------------");
        scanner.close();
    }
}
